<?php

namespace App\Http\Controllers;

use EasyWeChat\Factory;
use Illuminate\Http\Request;

class WechatController extends Controller
{
    //
    public function wechat()
    {
        echo 'true';
    }
    private function checkSignature() {

    }
}
